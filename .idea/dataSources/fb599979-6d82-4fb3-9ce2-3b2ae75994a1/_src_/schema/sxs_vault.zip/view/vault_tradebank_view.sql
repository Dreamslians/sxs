CREATE VIEW `vault_tradebank_view` AS
  SELECT
    `a`.`name`           AS `name`,
    `b`.`id`             AS `id`,
    `b`.`user_id`        AS `user_id`,
    `b`.`bank_id`        AS `bank_id`,
    `b`.`bank_name`      AS `bank_name`,
    `b`.`bank_no`        AS `bank_no`,
    `b`.`bank_stu`       AS `bank_stu`,
    `b`.`sxstrande_no`   AS `sxstrande_no`,
    `b`.`trande_no`      AS `trande_no`,
    `b`.`deal_id`        AS `deal_id`,
    `b`.`sign`           AS `sign`,
    `b`.`deal_money`     AS `deal_money`,
    `b`.`money`          AS `money`,
    `b`.`user_realname`  AS `user_realname`,
    `b`.`phone`          AS `phone`,
    `b`.`idcard`         AS `idcard`,
    `b`.`back_time`      AS `back_time`,
    `b`.`addtime`        AS `addtime`,
    `b`.`state_tag`      AS `state_tag`,
    `b`.`trande_money`   AS `trande_money`,
    `b`.`substance`      AS `substance`,
    `b`.`back_substance` AS `back_substance`,
    `b`.`sync_time`      AS `sync_time`,
    `b`.`async_time`     AS `async_time`,
    `b`.`tag`            AS `tag`,
    `b`.`redpackmoney`   AS `redpackmoney`,
    `b`.`redids`         AS `redids`,
    `b`.`vender_type`    AS `vender_type`
  FROM `sxs_vault`.`vault_bank` `a`
    JOIN `sxs_vault`.`vault_user_trade_log` `b`
  WHERE (`a`.`short` = `b`.`bank_stu`)